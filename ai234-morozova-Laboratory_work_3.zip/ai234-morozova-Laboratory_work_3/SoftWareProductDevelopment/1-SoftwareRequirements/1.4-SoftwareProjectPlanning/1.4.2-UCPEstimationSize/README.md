### Оцінка трудомісткості процесу розробки програмного продукту

[Таблиця](https://docs.google.com/spreadsheets/d/1Lf0lKjv71nuSMcB3-Df9FQf-7tBT-AlrTSlI19gtpEk/edit?usp=sharing)
